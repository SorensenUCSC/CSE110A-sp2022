
# Symbol Table exception, requires a line number and ID
class SymbolTableException(Exception):
    
    def __init__(self, lineno, ID):
        message = "Symbol table error on line: " + str(lineno) + "\nUndeclared ID: " + str(ID)
        super().__init__(message)    

#Implement all members of this class for Part 3
class SymbolTable:
    def __init__(self):
        pass

    def insert(self, ID, info):
        pass

    def lookup(self, ID):
        pass

    def push_scope(self):
        pass

    def pop_scope(self):
        pass

class ParserException(Exception):
    
    # Pass a line number, current lexeme, and what tokens are expected
    def __init__(self, lineno, lexeme, tokens):
        message = "Parser error on line: " + str(lineno) + "\nExpected one of: " + str(tokens) + "\nGot: " + str(lexeme)
        super().__init__(message)

class Parser:
    def __init__(self, scanner, use_symbol_table):
        self.scanner = scanner

    # Implement one function in this class for every non-terminal in
    # your grammar using the recursive descent recipe from the book
    # and the lectures for part 2

    # Implement me:
    # s is the string to parse
    def parse(self, s):
        pass

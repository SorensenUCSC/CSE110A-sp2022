

class ScannerException(Exception):
    
    # this time, the scanner exception takes a line number
    def __init__(self, lineno):
        message = "Scanner error on line: " + str(lineno)
        super().__init__(message)

class Scanner:
    def __init__(self, tokens):
        self.tokens = tokens
        self.lineno = 1

    def input_string(self, input_string):
        self.istring = input_string

    # Get the scanner line number, needed for the parser exception
    def get_lineno(self):
        return self.lineno

    # Implement me with one of your scanner implementations for part
    # 2. I suggest the SOS implementation. If you are not comfortable
    # using one of your own scanner implementations, you can use the
    # EMScanner implementation
    def token(self):    
        pass

def idy(x):
    return x

# Finish providing tokens (including token actions) for the C-simple
# language
tokens = [("LPAR", "\(", idy),
          ("RPAR", "\)", idy)]

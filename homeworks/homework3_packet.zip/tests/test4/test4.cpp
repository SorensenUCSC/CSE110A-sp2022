
void test4(float &x) {

  int i;
  for (i = 0; i < 100; i = i + 1) {
    x = x + i;
  }
  
}


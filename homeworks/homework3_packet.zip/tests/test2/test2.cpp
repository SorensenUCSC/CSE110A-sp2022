
void test2(float &f0, float &f1) {

  int x;
  int y;
  x = f0;
  y = f1;
  x = x + y;
  f0 = x;  
}


def idy(t):
    return t

tokens = [
    ("ID",     "[a-z]+", idy),
    ("NUM",    "[0-9]+", idy),
    ("IGNORE", " |\n",   idy)]
